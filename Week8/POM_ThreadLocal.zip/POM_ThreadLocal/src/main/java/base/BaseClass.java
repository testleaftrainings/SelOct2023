package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests{

	private static final ThreadLocal<RemoteWebDriver> rdDriver= new ThreadLocal<RemoteWebDriver>();

	public void setDriver(String browser) {
		if (browser.equalsIgnoreCase("chrome")) {
			rdDriver.set(new ChromeDriver());
		}
		else if(browser.equalsIgnoreCase("edge")) {
			rdDriver.set(new EdgeDriver());
		}
		else if(browser.equalsIgnoreCase("firefox")) {
			rdDriver.set(new FirefoxDriver());
		}


	}

	public RemoteWebDriver getDriver() {
		//		ChromeDriver chromeDriver = cdriver.get();
		//		return chromeDriver;

		return rdDriver.get();
	}

	public String excelSheetName;

	@Parameters("browser")
	@BeforeMethod
	public void precondition(String browser) {

		setDriver(browser);
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}

	@AfterMethod
	public void postCondition() {

		getDriver().quit();

	}

	@DataProvider(name="fetchData",indices=0)
	public String[][] sendData() throws IOException {
		return ReadExcel.readExcelData(excelSheetName);

	}

}
