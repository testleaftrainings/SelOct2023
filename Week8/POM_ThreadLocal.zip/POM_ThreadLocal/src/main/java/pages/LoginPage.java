package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass{

	@Given("Enter the username as {string}")
	public LoginPage enterUsername(String uName) {
		getDriver().findElement(By.id("username")).sendKeys(uName);
		return this;

	}

	@And("Enter the password as {string}")
	public LoginPage enterPassword(String pWord) {
		getDriver().findElement(By.id("password")).sendKeys(pWord);  
		return this;

	}

	@When("Click on the Login Button")
	public WelcomePage clickLoginButton() {   
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
	}

}
