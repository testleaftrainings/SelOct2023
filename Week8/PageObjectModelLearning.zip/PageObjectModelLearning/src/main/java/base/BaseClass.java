package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import utils.ReadExcel;

public class BaseClass {

	public  ChromeDriver driver;
	public String excelSheetName;
	
	@BeforeMethod
	public void precondition() {
		
		driver = new ChromeDriver();
		System.out.println("BeforeMethod: "+driver);
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}
	
	@AfterMethod
	public void postCondition() {

		driver.quit();

	}
	
	@DataProvider(name="fetchData",indices=0)
	public String[][] sendData() throws IOException {
		return ReadExcel.readExcelData(excelSheetName);

	}

}
