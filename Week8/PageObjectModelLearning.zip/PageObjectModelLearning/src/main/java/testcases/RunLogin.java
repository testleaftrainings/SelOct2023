package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunLogin extends BaseClass{
	
	@BeforeTest
	public void setValues() {
		
		excelSheetName="Sheet1";

	}
	
	@Test(dataProvider="fetchData")
	public void runLoginTestcase(String uName,String pWord) {
		
//		LoginPage lp = new LoginPage();
//		lp.enterUsername();
//		lp.enterPassword();
//		lp.clickLoginButton();
//		
//		WelcomePage wp = new WelcomePage();
//		wp.verifyHomePage();
//		wp.clickCrmsfaLink();
		System.out.println("LoginTestMethod: "+driver);
		LoginPage lp = new LoginPage(driver);
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.verifyHomePage();

	}

}
