package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunCreateLead extends BaseClass{
	

	@BeforeTest
	public void setValues() {
		
		excelSheetName="Sheet2";

	}

	@Test(dataProvider = "fetchData")
	public void runCreateLeadTestcase(String uName,String pWord,String cName,String fName,String lName) {
		System.out.println("CreateLeadTestMethod: "+driver);
		LoginPage lp = new LoginPage(driver);
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.clickCrmsfaLink()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyName(cName)
		.enterFirstName(fName)
		.enterLastName(lName)
		.clickSumbitButton()
		.verifyLeads();

	}
	
}
