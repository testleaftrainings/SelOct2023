package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends BaseClass{
	
	@Then("HomePage should be displayed")	
	public WelcomePage verifyHomePage() {
		
		String text = driver.findElement(By.tagName("h2")).getText();
		if (text.contains("Welcome")) {
			System.out.println("HomePage is displayed");
		}
		else {
			System.out.println("HomePage is not displayed");
		}
		return this;
	}
	
	@When("Click on crmsfa link")
	public MyHomePage clickCrmsfaLink() {
		driver.findElement(By.partialLinkText("CRM")).click();
		return new MyHomePage();

	}

}
