package utils;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	public static String[][] readExcelData(String sheetName) throws IOException {
		XSSFWorkbook wb = new XSSFWorkbook("./data/Login.xlsx");
		XSSFSheet wSheet = wb.getSheet(sheetName);
		int rowCount = wSheet.getLastRowNum();
		System.out.println("rowCount: "+rowCount);
		short columnCount = wSheet.getRow(0).getLastCellNum();
		System.out.println("columnCount : "+columnCount);
		String[][] data = new String[rowCount][columnCount];
		for (int i = 1; i <= rowCount; i++) {
			XSSFRow eachRow = wSheet.getRow(i);
			for (int j = 0; j < columnCount; j++) {
				String allDatas = eachRow.getCell(j).getStringCellValue();
				System.out.println(allDatas);
				data[i-1][j]=allDatas;
			}                 
		}

		wb.close();
		return data;


	}

}
