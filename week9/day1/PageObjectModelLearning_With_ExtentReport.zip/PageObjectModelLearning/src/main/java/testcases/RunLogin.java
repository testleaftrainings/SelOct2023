package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunLogin extends BaseClass{
	
	@BeforeTest
	public void setValues() {
		
		excelSheetName="Sheet1";
		testName="Leaftaps_Login";
		testDescription="Login with positive data";
		testCategory="Smoke";
		testAuthor="Hari";

	}
	
	@Test(dataProvider="fetchData")
	public void runLoginTestcase(String uName,String pWord) throws IOException {
		
//		LoginPage lp = new LoginPage();
//		lp.enterUsername();
//		lp.enterPassword();
//		lp.clickLoginButton();
//		
//		WelcomePage wp = new WelcomePage();
//		wp.verifyHomePage();
//		wp.clickCrmsfaLink();
		System.out.println("LoginTestMethod: "+driver);
		LoginPage lp = new LoginPage(driver);
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.verifyHomePage();

	}

}
